module.exports = { 
  mysqlHost: "13.233.12.75",
    user: "esp",
    password: 'Espsoft123#',
    database: "quant_fund",
    mysqlPort: 3306,
    JWT_SECRET_KEY: 'ly27lg35kci85tvgvl0zgbod4',
    SESSION_EXPIRES_IN: '24h',
    imageUrl:'',
    contractAddress : '0x98Ff86eD5B0dDd3C85115845A90A6066C25bedf9', //test
    clientDepositAddress:'0xEfcd2e9ca6483147A25a106C654a6E557eb8f916',
    // mailUrl : 'http://localhost:3000/silky_exchange/',


// contractAddress: "0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56", //LIVE
}